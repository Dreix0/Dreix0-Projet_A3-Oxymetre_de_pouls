#include "define.h"

oxy mesureTest(char* filename);

	
oxy CalculMesure(absorp donneevpp, oxy myOxy, float* nbP_acir, float* nbN_acir, float* nbP_acr, float* nbN_acr, float* memo_acr);
