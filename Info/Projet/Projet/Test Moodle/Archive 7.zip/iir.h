#include "define.h"


absorp iirTest(char* filename);
absorp Calculiir(absorp myAbsorpdonne,float *memoire_iir_acr,float *memoire_iir_acir);
