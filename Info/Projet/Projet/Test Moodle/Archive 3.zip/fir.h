#include "define.h"

absorp firTest(char* filename);
absorp Calculfir(absorp myAbsorpdonne,float *memoire_fir_acr,float *memoire_fir_acir);
