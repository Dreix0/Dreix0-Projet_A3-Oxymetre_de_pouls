#include "define.h"

oxy mesureTest(char* filename);

	
oxy CalculMesure(absorp donneevpp, oxy myOxy,nbp nb, float* memo_acr, int* psg0,float *cpt);
