#include "iir.h"
#include "fichiers.h"
#include "define.h"
#include "stdlib.h"
#include "stdio.h"
absorp iirTest(char* filename){
	absorp	myAbsorp;
	absorp	myAbsorpdonne;

	int etat=0;
	FILE* pf=initFichier(filename);
	float memoire_iir_acr[3]={0,0,0};
	float memoire_iir_acir[3]={0,0,0};

	//lecture du fichier ligne à ligne

	myAbsorpdonne=lireFichier(pf,&etat);


	while(etat!=EOF)
	{
		//on filtre la ligne courante
		myAbsorp=Calculiir(myAbsorpdonne,memoire_iir_acr,memoire_iir_acir);
		myAbsorpdonne=lireFichier(pf,&etat);

	}
	fclose(pf);
	return myAbsorp;


}

absorp Calculiir(absorp myAbsorpdonne,float *memoire_iir_acr,float *memoire_iir_acir)
{

	float alpha=0.992;

	memoire_iir_acr[0]=myAbsorpdonne.acr;
	myAbsorpdonne.acr=memoire_iir_acr[0]-memoire_iir_acr[1]+alpha*memoire_iir_acr[2];
	memoire_iir_acr[1]=memoire_iir_acr[0];
	memoire_iir_acr[2]=myAbsorpdonne.acr;




	memoire_iir_acir[0]=myAbsorpdonne.acir;
	myAbsorpdonne.acir=memoire_iir_acir[0]-memoire_iir_acir[1]+alpha*memoire_iir_acir[2];

	memoire_iir_acir[1]=memoire_iir_acir[0];
	memoire_iir_acir[2]=myAbsorpdonne.acir;


	return myAbsorpdonne;


}
