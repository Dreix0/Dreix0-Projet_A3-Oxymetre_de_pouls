#include "define.h"

absorp firTest(char* filename);