#include "mesure.h"
#include "fichiers.h"
#include "define.h"
oxy mesureTest(char* filename){
	oxy myOxy;
	//absorp	myAbsorp;

	absorp	donneevpp;
	float vpp_acir=0;
	float vpp_acr=0;
	float nbP_acir=0;
	float nbN_acir=0;
	float nbP_acr=0;
	float nbN_acr=0;
	float RSIR=0;
	float freq=0;
	int spo2;
	float freq_finale=0;
	float memo_acr;
	int psg0=1;
	int etat=0;
	FILE* VPP=initFichier(filename); //on utilisera le fichier "record1_fir.dat" qui est l'entrée du bloc iir

	donneevpp=lireFichier(VPP,&etat);

	while(etat!=EOF){
		donneevpp=lireFichier(VPP,&etat);
		myOxy=CalculMesure(donneevpp, myOxy, &nbP_acir,&nbN_acir,&nbP_acr,&nbN_acr, &memo_acr, &psg0);
	}
	fclose(VPP);
	return myOxy;

}

oxy CalculMesure(absorp donneevpp, oxy myOxy, float* nbP_acir, float* nbN_acir, float* nbP_acr, float* nbN_acr, float* memo_acr, int* psg0){

	float vpp_acir=0;
	int spo2;
	float RSIR=0;
	float freq_finale=0;
	float freq=0;
	float vpp_acr=0;

	if(*nbP_acir<donneevpp.acir){
		*nbP_acir=donneevpp.acir;
	}
	if(*nbN_acir>donneevpp.acir){
		*nbN_acir=donneevpp.acir;
	}
	if(*nbP_acr<donneevpp.acr){
		*nbP_acr=donneevpp.acr;
	}
	if(*nbN_acr>donneevpp.acr){
		*nbN_acr=donneevpp.acr;
	}
	if(*psg0<3){
		if(donneevpp.acr>0 && *memo_acr<0){
			*psg0+=1;
		}
		  if(donneevpp.acr<0 && *memo_acr>0){
			  *psg0+=1;
		  }
	}
	else{
		vpp_acir=*nbP_acir-*nbN_acir;
		vpp_acr=*nbP_acr-*nbN_acr;
		//printf("%f\n%f",vpp_acir,vpp_acr);
		if(donneevpp.dcr!=0 && donneevpp.dcir!=0){
			RSIR=(vpp_acr/donneevpp.dcr)/(vpp_acir/donneevpp.dcir);

		}
		if(RSIR>=0.4 && RSIR<=1){
			spo2=-25*RSIR+110;

		}else if (RSIR>=1 && RSIR<=3.4){
			spo2=-33.3*RSIR+113;
		}
		myOxy.spo2=spo2;
		*nbP_acir=0;
		*nbN_acir=0;
		*nbP_acr=0;
		*nbN_acr=0;
		*psg0=1;
	}
	//myOxy.spo2=(100/(-3))*RSIR+(100/3)*0.4+100;

	*memo_acr=donneevpp.acr;
	myOxy.pouls=(1/freq_finale)*60;
	return myOxy;
}
