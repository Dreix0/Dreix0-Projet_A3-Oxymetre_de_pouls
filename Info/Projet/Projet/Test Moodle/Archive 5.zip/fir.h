#include "define.h"

absorp firTest(char* filename);
absorp Calculfir(absorp myAbsorpdonnee,float *memoire_fir_acr,float *memoire_fir_acir,float *FIR_TAPS);
