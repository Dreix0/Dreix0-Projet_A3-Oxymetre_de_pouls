#include "mesure.h"

oxy mesureTest(char* filename){
	oxy myOxy;
	return myOxy;

}

