#include "define.h"


absorp iirTest(char* filename);
absorp CalculIIR(absorp myAbsorp, float* tab_acr, float* tab_acir);