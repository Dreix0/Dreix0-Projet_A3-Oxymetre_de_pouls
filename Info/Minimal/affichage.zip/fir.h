#include "define.h"

absorp firTest(char* filename);

absorp Calculfir(absorp new_myAbsorp,float *tab_acr,float *tab_acir,float *FIR_TAPS);