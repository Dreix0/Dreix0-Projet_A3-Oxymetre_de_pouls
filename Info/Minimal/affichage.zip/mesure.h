#include "define.h"

oxy mesureTest(char* filename);

oxy CalculMesure(absorp donneevpp, oxy myOxy, float memo_acr, int* psg0,int *cpt);	
