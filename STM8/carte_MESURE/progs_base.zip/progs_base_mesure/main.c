/* MAIN.C file
 * 
 * Copyright (c) 2002-2005 STMicroelectronics
 */
#include <iostm8s105.h>

main()
{
	while (1);
}