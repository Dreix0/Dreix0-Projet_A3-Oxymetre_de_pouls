void Init_I2C_Master(void);
void Start_I2C(void);
void Write_I2C(uint8_t data);
uint8_t Read_I2C(void);
void Ack_I2C(void);
void NoAck_I2C(void);
void Stop_I2C(void);

