
//prototype fonctions 
//simu_1





//simu_2





//simu_f


